			document.addEventListener("deviceready", onDeviceReady, false);
			function onDeviceReady() {
			if (window.MobileAccessibility) {
				window.MobileAccessibility.usePreferredTextZoom(false);
				
			}
			}
			var subject = sessionStorage.getItem("subject");
	        var Qnum = sessionStorage.getItem(subject);
			var Qnum_arange = Qnum - 1;
		    var sbj_list = sessionStorage.getItem(subject + "_List");
			var sbj_list_fix = JSON.parse(sbj_list);
	        var Qnum_fix = sbj_list_fix[Qnum_arange];
	        var data = sbj_list_fix[Qnum_arange];
	        var data_number = subject +"Q"+ Qnum;
	        var Qdata = sessionStorage.getItem(data_number);
            var Qdata_fix = JSON.parse(Qdata);
			sessionStorage.setItem("prevchoice", Qdata_fix.choice);
			
		
    function getquestion(){
		    answered_qstn_indicator();
		    var optionafix = data + "optionA";
       	    var optionbfix = data + "optionB";
       	    var optioncfix = data + "optionC";
       	    var optiondfix = data + "optionD";
       	    var correctAns =data + "CRT";

       		
			var qustionfix = eval(data);
       		var optionAfix = eval(optionafix);
       	    var optionBfix = eval(optionbfix);
       	    var optionCfix = eval(optioncfix);
       	    var optionDfix = eval(optiondfix);
       	    var CrtOption = eval(correctAns);

			
	        document.getElementById("qstnNo").innerHTML= Qnum;
	        document.getElementById("question").innerHTML= qustionfix;
	        document.getElementById("optionA").innerHTML= optionAfix;
			document.getElementById("optionB").innerHTML= optionBfix;
            document.getElementById("optionC").innerHTML= optionCfix;
            document.getElementById("optionD").innerHTML= optionDfix;
            document.getElementById("ans").value= CrtOption;
            if(Qnum == "1"){
            document.getElementById("backwardbtn").innerHTML= "";
            document.getElementById("forwardbtn").innerHTML= "";
		    }
			else if(Qnum == "50"){
		    document.getElementById("centerbtn").innerHTML= "";
			document.getElementById("forwardbtn").innerHTML= "<b><span class='nextbtn' onclick='s()' style='background-color:orangered; padding-right:12px; padding-left:12px' data-toggle='modal' data-target='#myModal_submit'>Submit</span></b>";
			}
		    else{
		    document.getElementById("centerbtn").innerHTML= "";
		    }
            document.getElementById(Qdata_fix.choice).style.backgroundColor="skyblue";
			
			//tmer_maker();	
			
	}

	
	
	
	
	
	
	




    
	                     

                     
     
  